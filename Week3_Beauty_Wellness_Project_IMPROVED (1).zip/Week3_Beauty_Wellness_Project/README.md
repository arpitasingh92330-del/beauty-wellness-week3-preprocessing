# Week 3: Data Cleaning and Preprocessing Pipeline — Beauty & Wellness

## Purpose
This project demonstrates a reproducible cleaning pipeline for beauty-product review records. **The provided input CSV is synthetic** and contains intentionally messy examples. It is not real customer data.

## Main files
- `Week3_Data_Cleaning_and_Preprocessing_Pipeline.docx`: main assignment report.
- `data/raw/beauty_reviews_raw_simulated.csv`: deliberately messy synthetic input.
- `src/preprocess_pipeline.py`: executable pipeline.
- `data/processed/beauty_reviews_cleaned.csv`: generated accepted records with clean fields and quality flags.
- `data/processed/quarantine_rows.csv`: records with missing or duplicate review identifiers.
- `data/reports/cleaning_summary.json`: input hash, row counts and flag counts.
- `data/reports/field_missingness_report.csv`: field-by-field missingness.
- `docs/preprocessing_flowchart.png`: overall pipeline flowchart.
- `docs/data_dictionary.csv`, `docs/source_register.csv`: reference tables.
- `outputs/`: plots created from synthetic demo data.

## Run
Requires Python 3.10+. From this directory:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python src/preprocess_pipeline.py
```

For a compatible, permitted CSV, use:
```bash
python src/preprocess_pipeline.py --input data/raw/your_permitted_export.csv --output-dir data/processed_real --reports-dir data/reports_real
```

## Core design choices
- Raw input remains unchanged; SHA-256 is stored in the JSON summary.
- Input is first loaded as strings to avoid uncontrolled type inference.
- Invalid/out-of-range ratings are set to missing and flagged; the target is never imputed.
- Currency symbols are parsed into amount + currency code, but there is no automatic FX conversion.
- Outliers are flagged for review rather than automatically deleted.
- Missing/duplicate review IDs are quarantined with row-level reasons.
- Assertions verify uniqueness, rating range and positive non-missing price amounts.

## Important assumptions
The demo assumes a 1–5 rating scale and uses day-first parsing for ambiguous dates. Verify both assumptions against the actual dataset. Review source terms/licensing and minimize personal data before collecting or sharing real reviews.


## Report visuals added in the improved edition

- `docs/preprocessing_flowchart.png`: eight-stage input → process → output flow.
- `docs/cleaning_decision_logic.png`: rating and price decision trees.
- `docs/outputs_audit_diagram.png`: output artifact map.
- `docs/implementation_gantt_32h.png`: cumulative 32-hour implementation chart.
- `outputs/`: simulated diagnostic plots; re-generate when a real, permitted dataset is substituted.
