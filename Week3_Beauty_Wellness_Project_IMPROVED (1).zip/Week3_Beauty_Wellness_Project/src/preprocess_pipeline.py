"""Reproducible, conservative cleaning pipeline for a beauty-product review CSV.

The included input is entirely synthetic and exists only for demonstration.
Run from project root: python src/preprocess_pipeline.py
Optional: python src/preprocess_pipeline.py --input data/raw/your_file.csv --output-dir data/processed
"""
from __future__ import annotations
import argparse, hashlib, json, re, sys
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd

PIPELINE_VERSION = "1.0.0"
MISSING_TOKENS = {"", "na", "n/a", "null", "none", "nan", "not available", "-", "--", "?"}
REQUIRED_COLUMNS = {"review_id", "product_id", "rating", "review_text"}
CATEGORY_MAP = {
    "skin care": "skincare", "skin-care": "skincare", "face care": "skincare", "facial care": "skincare",
    "skin care products": "skincare", "skincare": "skincare", "hair care": "haircare", "hair-care": "haircare",
    "haircare": "haircare", "make up": "makeup", "make-up": "makeup", "makeup": "makeup",
    "bath & body": "bath_body", "bath and body": "bath_body", "body care": "bath_body",
    "sun care": "suncare", "sun-care": "suncare", "suncare": "suncare"
}

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def normalize_missing(value):
    if pd.isna(value):
        return pd.NA
    s = str(value).replace("\u00a0", " ").strip()
    return pd.NA if s.casefold() in MISSING_TOKENS else s

def parse_numeric_token(value):
    """Extract a numeric token while tolerating separators; return NaN if not parseable."""
    if pd.isna(value):
        return np.nan
    s = str(value).strip().replace(",", "")
    m = re.search(r"[-+]?(?:\d+\.?\d*|\.\d+)", s)
    if not m:
        return np.nan
    try:
        return float(m.group(0))
    except ValueError:
        return np.nan

def parse_currency(price_raw, currency_raw):
    cur = "" if pd.isna(currency_raw) else str(currency_raw).strip().casefold()
    mapping = {"inr":"INR", "rs":"INR", "rs.":"INR", "rupee":"INR", "rupees":"INR", "₹":"INR",
               "usd":"USD", "$":"USD", "eur":"EUR", "€":"EUR", "gbp":"GBP", "£":"GBP"}
    code = mapping.get(cur, str(currency_raw).strip().upper() if cur else "")
    raw = "" if pd.isna(price_raw) else str(price_raw)
    if not code:
        if "₹" in raw or re.search(r"\b(inr|rs\.?|rupees?)\b", raw, re.I): code = "INR"
        elif "$" in raw or re.search(r"\busd\b", raw, re.I): code = "USD"
        elif "€" in raw or re.search(r"\beur\b", raw, re.I): code = "EUR"
        elif "£" in raw or re.search(r"\bgbp\b", raw, re.I): code = "GBP"
    return code or pd.NA

def canonical_category(value):
    if pd.isna(value): return pd.NA
    s = re.sub(r"\s+", " ", str(value).strip().lower())
    return CATEGORY_MAP.get(s, re.sub(r"[^a-z0-9]+", "_", s).strip("_"))

def write_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

def run_pipeline(input_path: Path, output_dir: Path, reports_dir: Path | None = None):
    reports_dir = reports_dir or output_dir.parent / "reports"
    output_dir.mkdir(parents=True, exist_ok=True); reports_dir.mkdir(parents=True, exist_ok=True)
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")
    raw = pd.read_csv(input_path, dtype="string", keep_default_na=False, encoding="utf-8")
    raw_rows = len(raw)
    # Normalize column labels before inspecting required fields.
    original_columns = list(raw.columns)
    raw.columns = [re.sub(r"[^a-z0-9]+", "_", str(c).strip().lower()).strip("_") for c in raw.columns]
    duplicate_columns = raw.columns[raw.columns.duplicated()].tolist()
    if duplicate_columns:
        raise ValueError(f"Duplicate column names after normalization: {duplicate_columns}")
    missing_required = sorted(REQUIRED_COLUMNS - set(raw.columns))
    if missing_required:
        raise ValueError(f"Missing required columns: {missing_required}. Found: {list(raw.columns)}")
    df = raw.copy()
    df.insert(0, "source_row_number", np.arange(2, raw_rows + 2))  # CSV line number including header
    # Normalize explicit missing sentinels consistently in all source fields.
    for col in raw.columns:
        df[col] = df[col].map(normalize_missing).astype("string")
    # Retain raw representations for audit and make a whitespace-clean review text field.
    for col in ["rating", "price", "review_date", "helpful_votes", "currency", "verified_purchase"]:
        if col in df.columns:
            df[f"{col}_raw"] = df[col]
    for col in ["brand", "product_name", "product_id", "review_id", "skin_type", "source"]:
        if col in df.columns:
            df[col] = df[col].astype("string").str.strip().replace({"": pd.NA})
    if "review_text" in df.columns:
        df["review_text"] = (df["review_text"].astype("string").str.replace(r"\s+", " ", regex=True).str.strip())
        df.loc[df["review_text"].eq(""), "review_text"] = pd.NA
        df["review_text_length"] = df["review_text"].str.len().astype("Float64")
    if "category" in df.columns:
        df["category_raw"] = df["category"]
        df["category"] = df["category"].map(canonical_category).astype("string")
    if "brand" in df.columns:
        df["brand"] = df["brand"].map(lambda x: pd.NA if pd.isna(x) else re.sub(r"\s+", " ", str(x)).strip().title()).astype("string")
    if "skin_type" in df.columns:
        df["skin_type"] = df["skin_type"].map(lambda x: pd.NA if pd.isna(x) or str(x).strip().lower() in {"unknown", "unspecified", "not stated"} else str(x).strip().lower()).astype("string")
    # Rating: preserve raw source, parse numeric values and common forms, never impute the target.
    rating_text = df["rating_raw"].astype("string") if "rating_raw" in df.columns else df["rating"].astype("string")
    df["rating"] = rating_text.map(parse_numeric_token).astype("Float64")
    rating_nonmissing_raw = rating_text.notna() & ~rating_text.str.strip().str.lower().isin(MISSING_TOKENS)
    invalid_rating = rating_nonmissing_raw & (df["rating"].isna() | ~df["rating"].between(1, 5, inclusive="both").fillna(False))
    df.loc[invalid_rating, "rating"] = pd.NA
    df["invalid_rating_flag"] = invalid_rating.astype(bool)
    # Price: parse amount and currency independently. Do NOT convert currencies without a dated FX source.
    if "price" in df.columns:
        price_text = df["price_raw"].astype("string") if "price_raw" in df.columns else df["price"].astype("string")
        cur_text = df["currency_raw"] if "currency_raw" in df.columns else df.get("currency", pd.Series(pd.NA, index=df.index, dtype="string"))
        df["currency_code"] = [parse_currency(p, c) for p, c in zip(price_text, cur_text)]
        df["price_amount"] = price_text.map(parse_numeric_token).astype("Float64")
        price_nonmissing_raw = price_text.notna() & ~price_text.str.strip().str.lower().isin(MISSING_TOKENS)
        invalid_price = price_nonmissing_raw & (df["price_amount"].isna() | (df["price_amount"] <= 0).fillna(False))
        df.loc[invalid_price, "price_amount"] = pd.NA
        df["invalid_price_flag"] = invalid_price.astype(bool)
    else:
        df["currency_code"] = pd.NA; df["price_amount"] = pd.NA; df["invalid_price_flag"] = False
    # Dates: explicit mixed-format parser, day-first policy documented for this demo; invalid dates become NA + flag.
    if "review_date" in df.columns:
        date_text = df["review_date_raw"].astype("string") if "review_date_raw" in df.columns else df["review_date"].astype("string")
        df["review_date"] = pd.to_datetime(date_text, format="mixed", dayfirst=True, errors="coerce")
        date_nonmissing_raw = date_text.notna() & ~date_text.str.strip().str.lower().isin(MISSING_TOKENS)
        df["invalid_date_flag"] = (date_nonmissing_raw & df["review_date"].isna()).astype(bool)
        future = df["review_date"].notna() & (df["review_date"].dt.date > datetime.now().date())
        df["future_date_flag"] = future.astype(bool)
        df.loc[future, "review_date"] = pd.NaT
    else:
        df["review_date"] = pd.NaT; df["invalid_date_flag"] = False; df["future_date_flag"] = False
    # Helpful votes: invalid and negative counts are missing, not coerced to zero.
    if "helpful_votes" in df.columns:
        vote_text = df["helpful_votes_raw"].astype("string") if "helpful_votes_raw" in df.columns else df["helpful_votes"].astype("string")
        df["helpful_votes"] = vote_text.map(parse_numeric_token).astype("Float64")
        bad_votes = df["helpful_votes"].notna() & ((df["helpful_votes"] < 0) | (df["helpful_votes"] % 1 != 0))
        vote_parse_fail = vote_text.notna() & ~vote_text.str.strip().str.lower().isin(MISSING_TOKENS) & df["helpful_votes"].isna()
        df.loc[bad_votes | vote_parse_fail, "helpful_votes"] = pd.NA
        df["invalid_helpful_votes_flag"] = (bad_votes | vote_parse_fail).astype(bool)
    if "verified_purchase" in df.columns:
        bool_map = {"yes":"true", "y":"true", "true":"true", "1":"true", "verified":"true", "no":"false", "n":"false", "false":"false", "0":"false", "unverified":"false"}
        df["verified_purchase"] = df["verified_purchase"].map(lambda x: pd.NA if pd.isna(x) else bool_map.get(str(x).strip().lower(), pd.NA)).astype("string")
        df["invalid_verified_purchase_flag"] = df.get("verified_purchase_raw", pd.Series(pd.NA, index=df.index)).notna() & df["verified_purchase"].isna()
    # Flags for absent critical/noncritical fields. A missing product ID limits joins but does not erase text evidence.
    df["missing_product_id_flag"] = df["product_id"].isna()
    df["missing_review_text_flag"] = df["review_text"].isna()
    df["missing_rating_flag"] = df["rating"].isna()
    # Price outliers: flag within a currency group only when group is reasonably sized; never delete by default.
    df["price_outlier_flag"] = False
    if "price_amount" in df.columns:
        for currency, idx in df[df["price_amount"].notna() & df["currency_code"].notna()].groupby("currency_code").groups.items():
            vals = df.loc[idx, "price_amount"].dropna()
            if len(vals) >= 8:
                q1, q3 = vals.quantile(.25), vals.quantile(.75); iqr = q3 - q1
                if iqr > 0:
                    flags = (df.loc[idx, "price_amount"] < q1 - 1.5*iqr) | (df.loc[idx, "price_amount"] > q3 + 1.5*iqr)
                    df.loc[idx, "price_outlier_flag"] = flags.fillna(False).astype(bool)
    # Conservative key-quality rule: do not train/evaluate on blank or duplicate review keys.
    quarantine_mask = df["review_id"].isna() | df["review_id"].duplicated(keep="first")
    quarantine = df.loc[quarantine_mask].copy()
    quarantine["quarantine_reason"] = np.where(quarantine["review_id"].isna(), "missing_review_id", "duplicate_review_id")
    clean = df.loc[~quarantine_mask].copy()
    # Detect repeated text/product combinations for review; preserve them to avoid deleting legitimate repeated feedback.
    norm_text = clean["review_text"].astype("string").str.lower().str.replace(r"[^a-z0-9]+", " ", regex=True).str.strip()
    product_norm = clean["product_id"].astype("string").str.lower()
    dup_text_product = norm_text.notna() & product_norm.notna() & pd.MultiIndex.from_arrays([product_norm, norm_text]).duplicated(keep=False)
    clean["possible_near_duplicate_flag"] = dup_text_product
    # Canonical output columns first, followed by source/raw fields and quality flags.
    preferred = ["review_id","product_id","product_name","brand","category","skin_type","rating","review_text","review_text_length","review_date","price_amount","currency_code","helpful_votes","verified_purchase","source","missing_product_id_flag","missing_review_text_flag","missing_rating_flag","invalid_rating_flag","invalid_price_flag","invalid_date_flag","future_date_flag","invalid_helpful_votes_flag","invalid_verified_purchase_flag","price_outlier_flag","possible_near_duplicate_flag","source_row_number"]
    cols = [c for c in preferred if c in clean.columns] + [c for c in clean.columns if c not in preferred]
    clean = clean[cols]
    # Assertions are hard gates: fail fast when core invariants are violated.
    assert clean["review_id"].notna().all(), "Clean output has missing review_id"
    assert clean["review_id"].is_unique, "Clean output has duplicate review_id"
    assert clean["rating"].dropna().between(1,5).all(), "Rating validation failed"
    assert clean["price_amount"].dropna().gt(0).all(), "Non-positive price survived validation"
    clean_path = output_dir / "beauty_reviews_cleaned.csv"
    quarantine_path = output_dir / "quarantine_rows.csv"
    clean.to_csv(clean_path, index=False, encoding="utf-8", date_format="%Y-%m-%d")
    quarantine.to_csv(quarantine_path, index=False, encoding="utf-8", date_format="%Y-%m-%d")
    # Quality metrics include raw versus accepted rows and missingness before/after.
    missing_rows=[]
    for col in raw.columns:
        raw_miss = raw[col].map(normalize_missing).isna().sum()
        after_col = col if col in clean.columns else None
        clean_miss = clean[after_col].isna().sum() if after_col else np.nan
        missing_rows.append({"field": col, "raw_missing_count": int(raw_miss), "raw_missing_pct": round(float(raw_miss/max(raw_rows,1)*100),2),
                             "clean_missing_count": int(clean_miss) if pd.notna(clean_miss) else None,
                             "clean_missing_pct": round(float(clean_miss/max(len(clean),1)*100),2) if pd.notna(clean_miss) else None})
    q_report = pd.DataFrame(missing_rows)
    q_report.to_csv(reports_dir / "field_missingness_report.csv", index=False)
    flag_counts = {col: int(clean[col].fillna(False).astype(bool).sum()) for col in clean.columns if col.endswith("_flag")}
    summary = {
        "pipeline_version": PIPELINE_VERSION,
        "run_timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "input_file": str(input_path), "input_sha256": sha256(input_path),
        "input_rows": int(raw_rows), "clean_rows": int(len(clean)), "quarantined_rows": int(len(quarantine)),
        "rows_removed_from_analysis": int(len(quarantine)), "fields": list(raw.columns),
        "missing_required_columns": [], "quarantine_reasons": quarantine["quarantine_reason"].value_counts().to_dict() if len(quarantine) else {},
        "cleaning_flags": flag_counts,
        "rating_non_missing_after_clean": int(clean["rating"].notna().sum()),
        "median_rating_after_clean": float(clean["rating"].median()) if clean["rating"].notna().any() else None,
        "price_outliers_flagged_not_removed": int(clean["price_outlier_flag"].sum()),
        "currency_policy": "Prices are parsed but never converted between currencies in this pipeline.",
        "target_policy": "Missing/invalid ratings are set to NA, not imputed.",
        "synthetic_demo_notice": "Input data are simulated; values are not real customer observations."
    }
    write_json(reports_dir / "cleaning_summary.json", summary)
    # Run log for quick review and audit.
    log_lines = [f"Pipeline version: {PIPELINE_VERSION}", f"Input SHA-256: {summary['input_sha256']}",
                 f"Input rows: {raw_rows}", f"Accepted rows: {len(clean)}", f"Quarantined rows: {len(quarantine)}",
                 f"Rating values retained: {clean['rating'].notna().sum()}", f"Price outliers flagged, not removed: {clean['price_outlier_flag'].sum()}",
                 "Hard validation assertions: PASS", "Note: synthetic demonstration input only."]
    (reports_dir / "run_log.txt").write_text("\n".join(log_lines)+"\n", encoding="utf-8")
    return clean, quarantine, summary

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input", default="data/raw/beauty_reviews_raw_simulated.csv")
    p.add_argument("--output-dir", default="data/processed")
    p.add_argument("--reports-dir", default="data/reports")
    args = p.parse_args()
    _, _, summary = run_pipeline(Path(args.input), Path(args.output_dir), Path(args.reports_dir))
    print(json.dumps(summary, indent=2, default=str))

if __name__ == "__main__":
    main()
